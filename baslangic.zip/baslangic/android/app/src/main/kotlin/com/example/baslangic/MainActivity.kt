package com.example.baslangic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
