class Configurations {
  static const _apiKey = "AIzaSyA8lg_YVrfKf82pSzzVErwPNSYS-nJGWnc";
  static const _projectId = "tirsan-smart";
  static const _messagingSenderId = "564937775172";
  static const _appId = "1:564937775172:web:b0e5f7b71a700f80df0411";

  String get apiKey => _apiKey;
  String get projectId => _projectId;
  String get messagingSenderId => _messagingSenderId;
  String get appId => _appId;
}
